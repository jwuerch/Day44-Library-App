--
-- Database: `library_test`
--
CREATE DATABASE IF NOT EXISTS `library_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library_test`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `title` varchar(255) DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `books_authors`
--

CREATE TABLE `books_authors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books_authors`
--

INSERT INTO `books_authors` (`id`, `book_id`, `author_id`) VALUES
(1, 43, 65),
(2, 44, 65),
(3, 52, 69),
(4, 52, 70),
(5, 53, 71),
(6, 57, 83),
(7, 58, 83),
(8, 69, 87),
(9, 69, 88),
(10, 70, 89),
(11, 74, 101),
(12, 75, 101),
(13, 86, 105),
(14, 86, 106),
(15, 87, 107),
(16, 91, 119),
(17, 92, 119),
(18, 103, 123),
(19, 103, 124),
(20, 104, 125),
(21, 108, 137),
(22, 109, 137),
(23, 120, 141),
(24, 120, 142),
(25, 121, 143),
(26, 125, 155),
(27, 126, 155),
(28, 137, 159),
(29, 137, 160),
(30, 138, 161),
(31, 142, 173),
(32, 143, 173),
(33, 154, 177),
(34, 154, 178),
(35, 155, 179),
(36, 159, 191),
(37, 160, 191),
(38, 168, 195),
(39, 168, 196),
(40, 169, 197),
(41, 173, 209),
(42, 174, 209),
(43, 185, 213),
(44, 185, 214),
(45, 186, 215),
(46, 190, 227),
(47, 191, 227),
(48, 202, 231),
(49, 202, 232),
(50, 203, 233),
(51, 207, 245),
(52, 208, 245),
(53, 219, 249),
(54, 219, 250),
(55, 220, 251),
(56, 224, 263),
(57, 225, 263),
(58, 229, 277),
(59, 230, 277),
(60, 234, 291),
(61, 235, 291),
(62, 239, 305),
(63, 240, 305),
(64, 244, 319),
(65, 245, 319),
(66, 249, 333),
(67, 250, 333),
(68, 254, 347),
(69, 255, 347),
(70, 259, 361),
(71, 260, 361),
(72, 264, 375),
(73, 265, 375),
(74, 269, 389),
(75, 270, 389),
(76, 274, 403),
(77, 275, 403),
(78, 286, 407),
(79, 286, 408),
(80, 287, 409),
(81, 291, 421),
(82, 292, 421),
(83, 303, 425),
(84, 303, 426),
(85, 304, 427),
(86, 308, 439),
(87, 309, 439),
(88, 317, 443),
(89, 317, 444),
(90, 318, 445),
(91, 550, 457),
(92, 551, 457),
(93, 559, 461),
(94, 559, 462),
(95, 560, 463),
(96, 573, 475),
(97, 574, 475),
(98, 582, 479),
(99, 582, 480),
(100, 583, 481),
(101, 596, 493),
(102, 597, 493),
(103, 605, 497),
(104, 605, 498),
(105, 606, 499),
(106, 619, 511),
(107, 620, 511),
(108, 628, 515),
(109, 628, 516),
(110, 629, 517),
(111, 642, 529),
(112, 643, 529),
(113, 651, 533),
(114, 651, 534),
(115, 652, 535),
(116, 665, 547),
(117, 666, 547),
(118, 674, 551),
(119, 674, 552),
(120, 675, 553),
(121, 688, 565),
(122, 689, 565),
(123, 697, 569),
(124, 697, 570),
(125, 698, 571),
(126, 712, 583),
(127, 713, 583),
(128, 721, 587),
(129, 721, 588),
(130, 722, 589),
(131, 736, 601),
(132, 737, 601),
(133, 745, 605),
(134, 745, 606),
(135, 746, 607),
(136, 770, 619),
(137, 771, 619),
(138, 779, 623),
(139, 779, 624),
(140, 780, 625),
(141, 797, 637),
(142, 798, 637),
(143, 806, 641),
(144, 806, 642),
(145, 807, 643),
(146, 822, 645),
(147, 822, 646),
(148, 823, 647),
(149, 838, 649),
(150, 838, 650),
(151, 839, 651),
(152, 854, 653),
(153, 854, 654),
(154, 855, 655),
(155, 870, 657),
(156, 870, 658),
(157, 871, 659),
(158, 886, 661),
(159, 886, 662),
(160, 887, 663),
(161, 902, 665),
(162, 902, 666),
(163, 903, 667),
(164, 915, 669),
(165, 915, 670),
(166, 916, 671),
(167, 928, 673),
(168, 928, 674),
(169, 929, 675),
(170, 941, 677),
(171, 941, 678),
(172, 942, 679),
(173, 954, 681),
(174, 954, 682),
(175, 955, 683),
(176, 967, 685),
(177, 967, 686),
(178, 968, 687),
(179, 980, 689),
(180, 980, 690),
(181, 981, 691),
(182, 993, 693),
(183, 993, 694),
(184, 994, 695),
(185, 1006, 697),
(186, 1006, 698),
(187, 1007, 699),
(188, 1019, 701),
(189, 1019, 702),
(190, 1020, 703),
(191, 1032, 705),
(192, 1032, 706),
(193, 1033, 707),
(194, 1045, 709),
(195, 1045, 710),
(196, 1046, 711),
(197, 1058, 713),
(198, 1058, 714),
(199, 1059, 715),
(200, 1072, 717),
(201, 1072, 718),
(202, 1073, 719),
(203, 1086, 721),
(204, 1086, 722),
(205, 1087, 723),
(206, 1100, 725),
(207, 1100, 726),
(208, 1101, 727),
(209, 1114, 729),
(210, 1114, 730),
(211, 1115, 731),
(212, 1161, 733),
(213, 1161, 734),
(214, 1162, 735);

-- --------------------------------------------------------

--
-- Table structure for table `copies`
--

CREATE TABLE `copies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `available` tinyint(1) NOT NULL,
  `due_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `copies_patrons`
--

CREATE TABLE `copies_patrons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `copy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `copies_patrons`
--

INSERT INTO `copies_patrons` (`id`, `patron_id`, `copy_id`) VALUES
(11, 11, 11),
(12, 11, 11),
(13, 38, 38),
(14, 38, 38),
(15, 52, 52),
(16, 52, 52),
(17, 66, 66),
(18, 66, 66),
(39, 112, 246),
(40, 113, 247),
(41, 114, 248),
(42, 115, 255),
(43, 116, 256),
(44, 117, 257),
(45, 118, 264),
(46, 119, 265),
(47, 120, 266),
(48, 121, 273),
(49, 122, 274),
(50, 123, 275),
(51, 124, 282),
(52, 125, 282),
(53, 126, 284),
(54, 127, 291),
(55, 128, 291),
(56, 129, 293),
(57, 130, 300),
(58, 131, 300),
(59, 132, 302),
(60, 143, 143),
(61, 143, 143),
(62, 147, 309),
(63, 148, 309),
(64, 149, 311),
(65, 160, 160),
(66, 160, 160),
(67, 164, 318),
(68, 165, 318),
(69, 166, 320),
(70, 177, 177),
(71, 177, 177),
(72, 181, 327),
(73, 182, 327),
(74, 183, 329),
(75, 194, 194),
(76, 194, 194),
(77, 198, 336),
(78, 199, 336),
(79, 200, 338),
(80, 211, 211),
(81, 211, 211),
(82, 215, 345),
(83, 216, 345),
(84, 217, 347),
(85, 228, 228),
(86, 228, 228),
(87, 232, 354),
(88, 233, 354),
(89, 234, 356),
(90, 246, 246),
(91, 246, 246),
(92, 250, 364),
(93, 251, 364),
(94, 252, 366),
(95, 263, 367),
(96, 264, 374),
(97, 265, 374),
(98, 266, 376),
(99, 277, 377),
(100, 298, 378),
(101, 309, 379),
(102, 320, 380),
(103, 321, 321),
(104, 321, 321),
(105, 335, 381),
(106, 336, 336),
(107, 336, 336),
(108, 350, 382),
(109, 351, 351),
(110, 351, 351),
(111, 365, 383),
(112, 366, 366),
(113, 366, 366),
(114, 380, 384),
(115, 381, 385),
(116, 381, 386),
(117, 395, 387),
(118, 396, 388),
(119, 396, 389),
(120, 400, 396),
(121, 401, 396),
(122, 402, 398),
(123, 413, 399),
(124, 414, 400),
(125, 414, 401),
(126, 428, 402),
(127, 429, 403),
(128, 429, 404),
(129, 433, 452),
(130, 434, 452),
(131, 435, 454),
(132, 436, 463),
(133, 437, 463),
(134, 438, 465),
(135, 439, 476),
(136, 440, 476),
(137, 441, 478),
(138, 442, 487),
(139, 443, 487),
(140, 444, 489),
(141, 445, 492),
(142, 446, 492),
(143, 447, 494),
(144, 448, 497),
(145, 449, 497),
(146, 450, 499),
(147, 451, 502),
(148, 452, 502),
(149, 453, 504),
(150, 454, 513),
(151, 455, 513),
(152, 456, 515);

-- --------------------------------------------------------

--
-- Table structure for table `patrons`
--

CREATE TABLE `patrons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `books_authors`
--
ALTER TABLE `books_authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `copies`
--
ALTER TABLE `copies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `copies_patrons`
--
ALTER TABLE `copies_patrons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `patrons`
--
ALTER TABLE `patrons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=737;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1223;
--
-- AUTO_INCREMENT for table `books_authors`
--
ALTER TABLE `books_authors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;
--
-- AUTO_INCREMENT for table `copies`
--
ALTER TABLE `copies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=520;
--
-- AUTO_INCREMENT for table `copies_patrons`
--
ALTER TABLE `copies_patrons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;
--
-- AUTO_INCREMENT for table `patrons`
--
ALTER TABLE `patrons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=457;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
