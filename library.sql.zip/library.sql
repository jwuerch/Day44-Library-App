--
-- Database: `library`
--
CREATE DATABASE IF NOT EXISTS `library` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `title` varchar(255) DEFAULT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`title`, `genre`, `id`) VALUES
('Ishmael', 'Sci-Fi', 2),
('Ishmael', 'Sci-Fi', 3),
('sdf', 'asdf', 4),
('sdf', 'asdf', 5),
('sdf', 'asdf', 6),
('sddf', 'sadf', 7),
('sddf', 'sadf', 8),
('asdfasdvwsrgwergergg', 'sadf', 9);

-- --------------------------------------------------------

--
-- Table structure for table `books_authors`
--

CREATE TABLE `books_authors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `copies`
--

CREATE TABLE `copies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `available` int(11) NOT NULL,
  `due_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `copies`
--

INSERT INTO `copies` (`id`, `book_id`, `available`, `due_date`) VALUES
(1, 1, 1, '3000-01-01'),
(2, 1, 1, '3000-01-01'),
(3, 1, 1, '3000-01-01'),
(4, 1, 1, '3000-01-01'),
(5, 1, 1, '3000-01-01'),
(6, 1, 1, '3000-01-01'),
(7, 1, 1, '3000-01-01'),
(8, 1, 1, '3000-01-01'),
(9, 1, 1, '3000-01-01'),
(10, 1, 1, '3000-01-01'),
(11, 1, 1, '3000-01-01'),
(12, 1, 1, '3000-01-01'),
(13, 1, 1, '3000-01-01'),
(14, 1, 1, '3000-01-01'),
(15, 1, 1, '3000-01-01'),
(16, 1, 1, '3000-01-01'),
(17, 1, 1, '3000-01-01'),
(18, 1, 1, '3000-01-01'),
(19, 1, 1, '3000-01-01'),
(20, 1, 1, '3000-01-01'),
(21, 1, 1, '3000-01-01'),
(22, 1, 1, '3000-01-01'),
(23, 1, 1, '3000-01-01'),
(24, 1, 1, '3000-01-01'),
(25, 1, 1, '3000-01-01'),
(26, 1, 1, '3000-01-01'),
(27, 1, 1, '3000-01-01'),
(28, 1, 1, '3000-01-01'),
(29, 1, 1, '3000-01-01'),
(30, 1, 1, '3000-01-01'),
(31, 1, 1, '3000-01-01'),
(32, 1, 1, '3000-01-01'),
(33, 1, 1, '3000-01-01'),
(34, 1, 1, '3000-01-01'),
(35, 1, 1, '3000-01-01'),
(36, 1, 1, '3000-01-01'),
(37, 1, 1, '3000-01-01'),
(38, 1, 1, '3000-01-01'),
(39, 1, 1, '3000-01-01'),
(40, 1, 1, '3000-01-01'),
(41, 1, 1, '3000-01-01'),
(42, 1, 1, '3000-01-01'),
(43, 1, 1, '3000-01-01'),
(44, 1, 1, '3000-01-01'),
(45, 1, 1, '3000-01-01'),
(46, 1, 1, '3000-01-01'),
(47, 1, 1, '3000-01-01'),
(48, 1, 1, '3000-01-01'),
(49, 1, 1, '3000-01-01'),
(50, 1, 1, '3000-01-01'),
(51, 1, 1, '3000-01-01'),
(52, 1, 1, '3000-01-01'),
(53, 1, 1, '3000-01-01'),
(54, 1, 1, '3000-01-01'),
(55, 1, 1, '3000-01-01'),
(56, 1, 1, '3000-01-01'),
(57, 1, 1, '3000-01-01'),
(58, 1, 1, '3000-01-01'),
(59, 1, 1, '3000-01-01'),
(60, 1, 1, '3000-01-01'),
(61, 1, 1, '3000-01-01'),
(62, 1, 1, '3000-01-01'),
(63, 1, 1, '3000-01-01'),
(64, 1, 1, '3000-01-01'),
(65, 1, 1, '3000-01-01'),
(66, 1, 1, '3000-01-01'),
(67, 1, 1, '3000-01-01'),
(68, 1, 1, '3000-01-01'),
(69, 1, 1, '3000-01-01'),
(70, 1, 1, '3000-01-01'),
(71, 1, 1, '3000-01-01'),
(72, 1, 1, '3000-01-01'),
(73, 1, 1, '3000-01-01'),
(74, 1, 1, '3000-01-01'),
(75, 1, 1, '3000-01-01'),
(76, 1, 1, '3000-01-01'),
(77, 1, 1, '3000-01-01'),
(78, 1, 1, '3000-01-01'),
(79, 1, 1, '3000-01-01'),
(80, 1, 1, '3000-01-01'),
(81, 1, 1, '3000-01-01'),
(82, 1, 1, '3000-01-01'),
(83, 1, 1, '3000-01-01'),
(84, 1, 1, '3000-01-01'),
(85, 1, 1, '3000-01-01'),
(86, 1, 1, '3000-01-01'),
(87, 1, 1, '3000-01-01'),
(88, 1, 1, '3000-01-01'),
(89, 1, 1, '3000-01-01'),
(90, 1, 1, '3000-01-01'),
(91, 1, 1, '3000-01-01'),
(92, 1, 1, '3000-01-01'),
(93, 1, 1, '3000-01-01'),
(94, 1, 1, '3000-01-01'),
(95, 1, 1, '3000-01-01'),
(96, 1, 1, '3000-01-01'),
(97, 1, 1, '3000-01-01'),
(98, 1, 1, '3000-01-01'),
(99, 1, 1, '3000-01-01'),
(100, 1, 1, '3000-01-01'),
(101, 1, 1, '3000-01-01'),
(102, 1, 1, '3000-01-01'),
(103, 1, 1, '3000-01-01'),
(104, 1, 1, '3000-01-01'),
(105, 1, 1, '3000-01-01'),
(106, 2, 1, '3000-01-01'),
(107, 2, 1, '3000-01-01'),
(108, 2, 1, '3000-01-01'),
(109, 2, 1, '3000-01-01'),
(110, 2, 1, '3000-01-01'),
(111, 3, 1, '3000-01-01'),
(112, 3, 1, '3000-01-01'),
(113, 3, 1, '3000-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `copies_patrons`
--

CREATE TABLE `copies_patrons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `copy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `patrons`
--

CREATE TABLE `patrons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `books_authors`
--
ALTER TABLE `books_authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `copies`
--
ALTER TABLE `copies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `copies_patrons`
--
ALTER TABLE `copies_patrons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `patrons`
--
ALTER TABLE `patrons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `books_authors`
--
ALTER TABLE `books_authors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `copies`
--
ALTER TABLE `copies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;
--
-- AUTO_INCREMENT for table `copies_patrons`
--
ALTER TABLE `copies_patrons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `patrons`
--
ALTER TABLE `patrons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
